/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "usb_device.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "TJ_MPU6050.h"  // MPU6050 IMU 센서 라이브러리
#include "usbd_cdc_if.h"  // USB CDC (Virtual COM Port) 인터페이스
#include "fonts.h"      // OLED 디스플레이 글꼴 라이브러리
#include "ssd1306.h"    // SSD1306 OLED 디스플레이 라이브러리
#include <stdio.h>       // 표준 입출력 함수 사용을 위한 라이브러리
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
char oled_buffer[30];    // OLED 출력 문자열을 저장하는 버퍼 (30바이트)
RawData_Def myAccelRaw, myGyroRaw; // MPU6050의 원시 가속도 및 자이로 데이터 구조체
ScaledData_Def myAccelScaled, myGyroScaled; // 변환된 가속도 및 자이로 데이터 구조체
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
// printf()를 USB CDC를 통해 출력할 수 있도록 `_write()` 함수 재정의
int _write(int file, char *ptr, int len) {
    CDC_Transmit_FS((uint8_t*) ptr, len);
    return len;
}
/* USER CODE END PFP */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
    MPU_ConfigTypeDef myMpuConfig; // MPU6050 설정 구조체 선언
  /* USER CODE END 1 */

  HAL_Init();  // HAL 라이브러리 초기화
  SystemClock_Config();  // 시스템 클럭 설정

  /* Initialize all configured peripherals */
  MX_GPIO_Init();  // GPIO 초기화
  MX_I2C3_Init();  // I2C3 초기화 (MPU6050, OLED 통신)
  MX_USB_DEVICE_Init();  // USB CDC 초기화
  SSD1306_Init(); // SSD1306 OLED 초기화

  // MPU6050 초기화 및 설정
  MPU6050_Init(&hi2c3);
  myMpuConfig.Accel_Full_Scale = AFS_SEL_4g;
  myMpuConfig.ClockSource = Internal_8MHz;
  myMpuConfig.CONFIG_DLPF = DLPF_184A_188G_Hz;
  myMpuConfig.Gyro_Full_Scale = FS_SEL_500;
  myMpuConfig.Sleep_Mode_Bit = 0;  // 정상 작동 모드 설정
  MPU6050_Config(&myMpuConfig);


  while (1) {
    // 센서 데이터 읽기
    MPU6050_Get_Accel_Scale(&myAccelScaled);
    MPU6050_Get_Gyro_Scale(&myGyroScaled);

    // USB CDC를 통해 데이터 전송
    printf("ACCEL: X=%.2f, Y=%.2f, Z=%.2f\r\n", myAccelScaled.x, myAccelScaled.y, myAccelScaled.z);
    printf("GYRO: X=%.2f, Y=%.2f, Z=%.2f\r\n", myGyroScaled.x, myGyroScaled.y, myGyroScaled.z);

    // OLED 화면 초기화
    SSD1306_Fill(SSD1306_COLOR_BLACK);

    // ACCEL 데이터 출력
    SSD1306_GotoXY(0, 0);
    SSD1306_Puts("ACCEL", &Font_7x10, 1);
    SSD1306_GotoXY(0, 20);
    sprintf(oled_buffer, "%.2f", myAccelScaled.x);
    SSD1306_Puts(oled_buffer, &Font_7x10, 1);
    SSD1306_GotoXY(0, 30);
    sprintf(oled_buffer, "%.2f", myAccelScaled.y);
    SSD1306_Puts(oled_buffer, &Font_7x10, 1);
    SSD1306_GotoXY(0, 40);
    sprintf(oled_buffer, "%.2f", myAccelScaled.z);
    SSD1306_Puts(oled_buffer, &Font_7x10, 1);

    // GYRO 데이터 출력
    SSD1306_GotoXY(60, 0);
    SSD1306_Puts("GYRO", &Font_7x10, 1);
    SSD1306_GotoXY(60, 20);
    sprintf(oled_buffer, "%.2f", myGyroScaled.x);
    SSD1306_Puts(oled_buffer, &Font_7x10, 1);
    SSD1306_GotoXY(60, 30);
    sprintf(oled_buffer, "%.2f", myGyroScaled.y);
    SSD1306_Puts(oled_buffer, &Font_7x10, 1);
    SSD1306_GotoXY(60, 40);
    sprintf(oled_buffer, "%.2f", myGyroScaled.z);
    SSD1306_Puts(oled_buffer, &Font_7x10, 1);

    // OLED 화면 갱신
    SSD1306_UpdateScreen();

    HAL_Delay(1000);  // 1초 대기 (출력 간격 설정)
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
