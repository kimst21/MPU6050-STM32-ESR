/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * - STM32와 MPU6050 센서를 사용하여 X, Y, Z 축 가속도 데이터를 읽고 SSD1306 OLED 디스플레이에 출력하는 프로그램입니다.
  * - 1초 간격으로 데이터를 갱신하여 화면에 표시합니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"          // STM32 초기화 및 주변장치 관련 헤더
#include "i2c.h"           // I2C 초기화 및 통신 제어 헤더
#include "gpio.h"          // GPIO 초기화 관련 헤더

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>         // 데이터 출력 및 문자열 변환 함수
#include "MPU6050.h"       // MPU6050 가속도계 센서 제어 라이브러리
#include "ssd1306.h"       // SSD1306 OLED 디스플레이 제어 라이브러리
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// 프로그램에서 사용하는 사용자 정의 데이터 타입 선언 가능
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// 프로그램에 필요한 매크로 정의 가능
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
// 프로그램에서 사용하는 매크로 선언 가능
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
char strCopy[30];          // OLED 디스플레이에 출력할 데이터를 저장할 문자열 버퍼
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);   // 시스템 클럭 설정 함수
/* USER CODE BEGIN PFP */
// 프로그램에서 사용하는 추가 함수 선언 가능
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// 사용자 정의 초기화 및 데이터 저장 영역
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  // 메인 함수 시작 전 초기 설정이 필요한 변수 선언
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  HAL_Init();                      // HAL 라이브러리 초기화
  SystemClock_Config();            // 시스템 클럭 설정

  MX_GPIO_Init();                  // GPIO 핀 초기화
  MX_I2C3_Init();                  // I2C3 초기화 (MPU6050 및 OLED 디스플레이 통신용)

  /* USER CODE BEGIN 2 */
  MPU6050_Initialization();        // MPU6050 가속도계 초기화
  SSD1306_Init();                  // SSD1306 OLED 디스플레이 초기화
  /* USER CODE END 2 */

  /* Infinite loop */
  while (1)
  {
    /* USER CODE BEGIN WHILE */
    if (MPU6050_DataReady() == 0)  // 센서 데이터 준비 상태 확인
    {
        MPU6050_ProcessData(&MPU6050); // 센서 데이터를 읽고 처리

        SSD1306_Clear();               // OLED 화면 초기화

        // X축 데이터 출력
        SSD1306_GotoXY(0, 0);          // X축 데이터 출력 위치 설정
        sprintf(strCopy, "X= %d", MPU6050.acc_x_raw); // X축 가속도 값을 문자열로 변환
        SSD1306_Puts(strCopy, &Font_11x18, 1);       // OLED 디스플레이에 출력
        SSD1306_UpdateScreen();        // OLED 화면 업데이트

        // Y축 데이터 출력
        SSD1306_GotoXY(0, 20);         // Y축 데이터 출력 위치 설정
        sprintf(strCopy, "Y= %d", MPU6050.acc_y_raw); // Y축 가속도 값을 문자열로 변환
        SSD1306_Puts(strCopy, &Font_11x18, 1);       // OLED 디스플레이에 출력
        SSD1306_UpdateScreen();        // OLED 화면 업데이트

        // Z축 데이터 출력
        SSD1306_GotoXY(0, 40);         // Z축 데이터 출력 위치 설정
        sprintf(strCopy, "Z= %d", MPU6050.acc_z_raw); // Z축 가속도 값을 문자열로 변환
        SSD1306_Puts(strCopy, &Font_11x18, 1);       // OLED 디스플레이에 출력
        SSD1306_UpdateScreen();        // OLED 화면 업데이트

        HAL_Delay(1000);               // 1초 대기 후 데이터 갱신
    }
    /* USER CODE END WHILE */
  }
  /* USER CODE END 3 */
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
